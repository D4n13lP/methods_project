import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Portada extends JFrame implements KeyListener {

    private JLabel titulo, logo; //componentes para el título y el logo
    private JTextArea datos; //componente para los datos de la escuela y el equipo
    private Timer timer; //componente para controlar el tiempo de la portada
    private VentanaMenu ventanaMenu; //componente para la ventana del menú

    public Portada() {
        super("Portada"); //título de la ventana
        setSize(800, 600); //tamaño de la ventana
        setLocationRelativeTo(null); //centrar la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //cerrar el programa al cerrar la ventana
        setLayout(new BorderLayout()); //usar un layout de borde

        //crear los componentes de la portada
        titulo = new JLabel("Proyecto de Métodos Numéricos", SwingConstants.CENTER); //crear el título con alineación centrada
        titulo.setFont(new Font("Arial", Font.BOLD, 32)); //establecer la fuente del título
        datos = new JTextArea(); //crear el área de texto para los datos
        datos.setText("Escuela: Nombre de la escuela\n" + //escribir los datos de la escuela
                      "Equipo: Nombre del equipo\n" + //escribir los datos del equipo
                      "Integrantes: Nombre de los integrantes"); //escribir los datos de los integrantes
        datos.setEditable(false); //hacer que el área de texto no se pueda editar
        datos.setFont(new Font("Arial", Font.PLAIN, 24)); //establecer la fuente del área de texto
        logo = new JLabel(); //crear el label para el logo
        logo.setIcon(new ImageIcon("logo.jpg")); //establecer el icono del logo con la imagen del archivo logo.jpg
        logo.setHorizontalAlignment(SwingConstants.RIGHT); //establecer la alineación horizontal del logo a la derecha
        logo.setVerticalAlignment(SwingConstants.TOP); //establecer la alineación vertical del logo a la parte superior

        //agregar los componentes a la ventana
        add(titulo, BorderLayout.NORTH); //agregar el título al borde norte
        add(datos, BorderLayout.CENTER); //agregar el área de texto al borde centro
        add(logo, BorderLayout.EAST); //agregar el logo al borde este

        //crear el timer para mostrar la portada durante 5 segundos
        timer = new Timer(5000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //mostrar la ventana del menú
                ventanaMenu.setVisible(true);
            }
        });
        //iniciar el timer
        timer.start();

        //crear la ventana del menú pero no mostrarla
        ventanaMenu = new VentanaMenu();

        //agregar un escuchador de tecla a la ventana
        addKeyListener(this);
    }

    //método que se ejecuta al presionar una tecla
    @Override
    public void keyPressed(KeyEvent e) {
        //obtener el código de la tecla presionada
        int codigo = e.getKeyCode();
        //comparar el código con la tecla Enter
        if (codigo == KeyEvent.VK_ENTER) {
            //cerrar la portada
            dispose();
            //abrir la ventana del menú
            ventanaMenu.setVisible(true);
        }
    }

    //método que se ejecuta al soltar una tecla
    @Override
    public void keyReleased(KeyEvent e) {
        //no hacer nada
    }

    //método que se ejecuta al escribir una tecla
    @Override
    public void keyTyped(KeyEvent e) {
        //no hacer nada
    }

    //método principal para ejecutar el programa
    public static void main(String[] args) {
        //crear una instancia de la clase Portada y mostrarla
        Portada p = new Portada();
        p.setVisible(true);
    }
}
